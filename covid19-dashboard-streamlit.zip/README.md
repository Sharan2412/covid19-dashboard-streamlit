
# Real-Time COVID-19 Dashboard

An interactive dashboard that visualizes real-time COVID-19 data.

## Features
- Live COVID-19 data via external API
- Country-specific case tracking
- Daily vs cumulative graphs
- Responsive charts using Plotly
- Easy deployment on Streamlit Cloud

## Technologies Used
- Python
- Streamlit
- Pandas
- Plotly
- REST API (disease.sh)

## Screenshots
*Insert screenshots here if available*

## Run Locally

1. Clone the repo
```bash
git clone https://github.com/yourusername/covid19-dashboard-streamlit.git
cd covid19-dashboard-streamlit
```

2. Install dependencies
```bash
pip install -r requirements.txt
```

3. Run the app
```bash
streamlit run app.py
```
