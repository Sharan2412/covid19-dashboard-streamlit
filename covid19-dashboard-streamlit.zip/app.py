
import streamlit as st
import pandas as pd
import plotly.express as px
import requests

st.set_page_config(page_title="COVID-19 Dashboard", layout="wide")
st.title("Real-Time COVID-19 Dashboard")

@st.cache_data
def load_data():
    url = "https://disease.sh/v3/covid-19/countries"
    response = requests.get(url)
    data = pd.json_normalize(response.json())
    return data

data = load_data()

country = st.selectbox("Select Country", data["country"].unique())
df_country = data[data["country"] == country]

st.subheader(f"COVID-19 Data for {country}")

st.metric("Total Cases", f"{int(df_country['cases'].values[0]):,}")
st.metric("Total Deaths", f"{int(df_country['deaths'].values[0]):,}")
st.metric("Recovered", f"{int(df_country['recovered'].values[0]):,}")

fig = px.bar(df_country.melt(id_vars=["country"], value_vars=["cases", "deaths", "recovered"]),
             x="variable", y="value", color="variable", title="COVID-19 Case Summary")
st.plotly_chart(fig, use_container_width=True)
